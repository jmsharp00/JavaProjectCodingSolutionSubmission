public class p5 {

    public static void main(String[] args) {

        //
        int a = 9;
        int b = 12;

        a = a + b;
        b = a - b;
        a = a - b;

        System.out.println("The swapped value of a is now "+a);
        System.out.println("The swapped value of b is now "+b);
    }
}
