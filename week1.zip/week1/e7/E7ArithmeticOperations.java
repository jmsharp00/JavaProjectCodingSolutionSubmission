package org.example.week1.e7;

public class E7ArithmeticOperations {
    public static void main(String[] args) {
        // Step 1: Declare the integer variables and assign values
        int num1, num2;
        num1=200;
        num2=100;

        // Step 2: Perform arithmetic operations
        int sum, difference, product, qoutient;
        sum=num1+num2;
        difference=num1-num2;
        product=num1*num2;
        qoutient=num1/num2;

        // Step 3: Print the results
        System.out.println(sum);
        System.out.println(difference);
        System.out.println(product);
        System.out.println(qoutient);

    }
}
