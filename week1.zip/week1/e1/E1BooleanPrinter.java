package org.example.week1.e1;

public class E1BooleanPrinter {
    public static void main(String[] args) {

        // boolean T or F
        boolean isTrue;
        boolean isFalse;
        isTrue = true;
        isFalse = false;
        System.out.println(isTrue);
        System.out.println(isFalse);


    }
}