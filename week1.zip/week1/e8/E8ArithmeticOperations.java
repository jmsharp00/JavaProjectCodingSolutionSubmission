package org.example.week1.e8;

public class E8ArithmeticOperations {
    public static void main(String[] args) {
        // Step 1: Declare the integer variables and assign values
        int width, height;
        width=5;
        height=8;

        // Step 2: Calculate the perimeter
        // Use the formula: perimeter = 2 * (width + height)
        // (Write your code here to calculate the perimeter)
        int perimeter=2*(width+height);

        // Step 3: Calculate the area
        // Use the formula: area = width * height
        // (Write your code here to calculate the area)
        int area=width*height;

        // Step 4: Print the results
       // System.out.println("The perimeter of a rectangle with width " + width + " and height " + height + " is equal to " + perimeter + " and the area equals to " + area);
        System.out.println("The perimeter of a rectangle with width " + width + " and height " + height + " is equal to " + perimeter + " and the area equals to "+ area);


    }
}

