package org.example.week1.e5;

public class E5AssignmentOperator {
    public static void main(String[] args) {
        // Step 1: Declare the String variable and set it to "Chen"
            String name;
            name="Chen";

        // Step 2: Declare the integer variable and set it to 50
            int age;
            age=50;

        // Step 3: Assign the value of age to iq
            int iq;
            iq=age;

        // Step 4: Print the name
            System.out.println(name);

        // Step 5: Print the age and iq on the same line
        System.out.print(age);
        System.out.print(iq);

    }
}
