package org.example.week1.e2;

public class E2AgePrinter {
    public static void main(String[] args) {
        // Declare int variable named age
        int age;
        age=4;
        // Print output
        System.out.println(age);

    }
}
