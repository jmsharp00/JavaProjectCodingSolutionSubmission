package org.example.week1.e4;

public class E4CreatingVariablesAndPrinting {
    public static void main(String[] args) {
        System.out.println("*");
        System.out.println("**");
        System.out.println("***");
        System.out.println("##");
        System.out.println("#");
    }
}
