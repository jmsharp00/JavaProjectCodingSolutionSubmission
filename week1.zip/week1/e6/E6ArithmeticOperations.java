package org.example.week1.e6;

public class E6ArithmeticOperations {
    public static void main(String[] args) {
        // Step 1: Declare the float variable and set it to 8.2
        float num1;
        num1=8.2f;

        // Step 2: Multiply the value by itself and store the result
        float mult=num1*num1;

        // Step 3: Print the result
        System.out.println("The multiplication of " + num1 + " with itself is equal to " + mult);
    }
}
