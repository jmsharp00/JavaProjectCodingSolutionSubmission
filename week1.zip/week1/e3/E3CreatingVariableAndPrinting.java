package org.example.week1.e3;

public class E3CreatingVariableAndPrinting {
    public static void main(String[] args) {
    // Declare boolean variable named myBoolean
        boolean myBoolean;
        myBoolean=false;
    // Declare double variable named money
        double money;
        money=99999.99;
    // Print output
        System.out.print(money); System.out.print(myBoolean);



    }
}
